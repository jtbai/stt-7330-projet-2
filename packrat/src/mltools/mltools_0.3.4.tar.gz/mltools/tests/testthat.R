library(testthat)
library(mltools)

test_check("mltools")